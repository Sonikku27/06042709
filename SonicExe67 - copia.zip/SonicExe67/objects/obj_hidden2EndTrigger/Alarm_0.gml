action_another_room(rm_robotnikLoading);

