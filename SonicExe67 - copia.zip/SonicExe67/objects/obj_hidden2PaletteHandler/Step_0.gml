__background_set( e__BG.Blend, 0, 255 );
if (instance_exists(obj_hidden2Floor)) obj_hidden2Floor.image_blend = c_black;
if (instance_exists(obj_robotnikSpriteMask)) obj_robotnikSpriteMask.image_blend = c_gray;
global.hudState = "hidden";

