vspeed = 0;

