global.tailsHiddenClear = 1;

