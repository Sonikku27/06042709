global.playerscore = 0;

