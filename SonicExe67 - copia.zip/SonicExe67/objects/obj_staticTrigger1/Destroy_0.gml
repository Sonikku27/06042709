createStatic(60);

